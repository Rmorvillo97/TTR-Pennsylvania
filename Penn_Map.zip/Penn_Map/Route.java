
/**
 * Used to hold a Ticket to Ride route.
 *
 * @author ls11brun
 */
public class Route {

    City source;
    City dest;
    TrainColor color;
    /*
     * There are routes where any set of train cards can be use
     * to claim it, so should there be a null value if there's 
     * a gray color on the route?
     */
    
    String[] stocks;

    int length;

    boolean isClaimed;

    /**
     * Constructor for objects of class Route
     * 
     */
    
    //There needs to be another parameter for a second traincolor because
    //of double colored routes.
    public Route(City s, City d, TrainColor c, int l, String[] stocks) {
        source = s;
        dest = d;
        color = c;
        length =l;
        this.stocks = stocks;
        
        isClaimed = false;
    }
    /*
     **
     * CONSTRUCTOR WILL NOT WORK WHEN COMPARING ROUTES
     *
     * 2nd Constructor to include 2nd color of a double lane route
     *
    public Route(City s, City d, TrainColor c1, TrainColor c2, int l, String[] stocks){
        source = s;
        dest = d;
        color = c1;
        color2 = c2;
        length = l;
        this.stocks = stocks;
    }
    */
    /**
     * Used to determine the point value of a Route of a given length.
     *
     * @param length
     * @return the point value of a Route of the specified length
     */
    public static int getPoints(int length) {
        
        switch (length) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 3:
                return 4;
            case 4:
                return 7;
            case 5:
                return 10;
            case 6:
                return 15;
            case 7:
                return 18;
            case 8:
                return 21;
        }

        //this is an error case. No route is worth zero points.
        return 0;
    }

    /**
     * Used to access this particular route's point value.
     * 
     * @return the number of points this route is worth.
     */
    public int getPoints() {
        return getPoints(this.length);
    }
}
