import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
/**
 * Class to be used to save information on a destination card
 * 
 * @author Jose Melendez
 * 
 */
public class DestCard
{
    public City src;
    public City destination;
    public int Value;
    public Image destImage;
    
    //BufferImage?
    //check BufferedImage class on API
    //Variables for starting and ending points: int start, int end, image type
   
    
    //DestCard card1 = new DestCard((Source && Destination)citiesList[], image(String), );
    /**
     * Constructor for objects of Destination cards
     */
    public DestCard(City s, City d, int value, File f ){
        src = s;
        destination = d;
        Value = value;
        
        try{destImage = ImageIO.read(f);}
        catch (IOException error){System.err.println(error);}
        
        
    }
    public int getValue(){return Value;}
    
    }

