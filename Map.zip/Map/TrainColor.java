/**
 * Used to set which colors a train card can be.
 * 
 * @author London Brunell
 */
public enum TrainColor {
    
    BLACK, RED, ORANGE, WHITE, BLUE, PINK, GREEN, YELLOW, WILD;
    
}
